import os
import sqlite3
from pathlib import Path

# Define the directory and database file name
APP_NAME = "modular_intelligence"
DB_NAME = "modular_intelligence.db"

# Singleton for database connection
_connection = None

def get_db_path():
    """Get the default database path."""
    app_dir = Path.home() / f".{APP_NAME}"
    app_dir.mkdir(exist_ok=True)  # Create directory if it doesn't exist
    return app_dir / DB_NAME

def initialize_database():
    """Initialize the database if it doesn't exist."""
    db_path = get_db_path()
    if not db_path.exists():
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            # Create necessary tables (example schema)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS agents (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT
            );
            """)
            conn.commit()
    return db_path

def get_connection():
    """Get a singleton SQLite connection."""
    global _connection
    if _connection is None:
        db_path = initialize_database()
        _connection = sqlite3.connect(db_path)
    return _connection

if __name__ == "__main__":
    db_path = initialize_database()
    print(f"Database initialized at: {db_path}")