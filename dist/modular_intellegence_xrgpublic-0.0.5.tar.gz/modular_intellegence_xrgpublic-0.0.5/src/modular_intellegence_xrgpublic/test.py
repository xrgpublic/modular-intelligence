import sqlite3
from database.config import Config

def test_database_connection():
    try:
        # Get the database connection
        connection = sqlite3.connect(Config.SQLITE_URI)
        cursor = connection.cursor()

        # Create a test table
        cursor.execute('CREATE TABLE IF NOT EXISTS test (id INTEGER PRIMARY KEY, name TEXT)')
        
        # Insert a test record
        cursor.execute('INSERT INTO test (name) VALUES (?)', ('Test Name',))
        
        # Commit the changes
        connection.commit()

        # Query the test table
        cursor.execute('SELECT * FROM test')
        rows = cursor.fetchall()
        
        print("Test records:", rows)

    except sqlite3.Error as e:
        print("SQLite error:", e)
    finally:
        # Close the connection
        if connection:
            connection.close()

# Run the test
if __name__ == "__main__":
    test_database_connection()