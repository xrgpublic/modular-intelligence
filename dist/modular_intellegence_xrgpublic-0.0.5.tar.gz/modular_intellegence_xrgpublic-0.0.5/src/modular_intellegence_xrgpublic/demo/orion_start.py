from agents.base import BaseAgent
from utils.prompts import *
from utils import conversation_formatter as cf
from stack import AgentStack
from colorama import init, Fore, Style
from database.config import Config
from database.init_db import init_database

init_database()

import os


# Parsing and prepping datasets ready
file_path = "utils\\datasets\\example_dataset.txt"
raw_datasets = cf.read_datasets_from_file(file_path)
print(f"Conversation: {raw_datasets}")
formatted_datasets = cf.format_datasets(raw_datasets, user_role="User Input", assistant_role="Assistant")

convo = cf.dataset_to_conversation(formatted_datasets)
titled_convo = cf.add_title(convo, "brain title", 'Brain description')

# Initialize brain agent with proper parameters
mischievous_bot = BaseAgent(
    name="Missy",
    description="Someone who is very mischievous",
    default_system_prompt=mischievous_bot,
    orchestrator_bot=False,
    test_mode=False  # Set to True to avoid some DB operations
)

# Adding dataset to agent
mischievous_bot.add_dataset(titled_convo)

mischievous_bot.start_session()
mischievous_bot.generate_response("howdy! tell me about yourself")

mischievous_bot.end_session()

stack1 = AgentStack(db_path=Config.DATABASE, name="Brain Holder", description="Holds my Brain")
stack1.create()
stack1.add_slot(bot=mischievous_bot)

print(f"Stack ID: {stack1.id}")
