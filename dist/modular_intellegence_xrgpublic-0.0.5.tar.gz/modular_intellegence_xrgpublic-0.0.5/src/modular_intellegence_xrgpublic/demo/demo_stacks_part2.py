import sqlite3
from colorama import init, Fore, Style
from dynamic_swarm.config import DB_PATH, ENABLE_FOREIGN_KEYS
from dynamic_swarm.utils.prompts import *
from dynamic_swarm.init_db import init_db
from dynamic_swarm.agents.base import BaseAgent
from ollama import generate, chat


# Initialize an agent with a pre-defined variables
def main():
    """Demonstrate loading and using an existing stack."""
    # Initialize colorama
    init(autoreset=True)
    
    # Connect to the database
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    if ENABLE_FOREIGN_KEYS:
        cursor.execute("PRAGMA foreign_keys = ON;")
    
    # Step 1: Initialize the Database
    
    #init_bots()

    init_db(DB_PATH)

    new_bot = BaseAgent()
    new_bot = BaseAgent.create_from_bot(
        source_bot_name="Smart Bot",
        new_bot_name="Cool Bot",
        new_description="A bot that remembers the conversation context",
        db_path=DB_PATH,
        checkpoint_number=1  # Load the final state with conversation context
    )
    #new_bot.load_from_db(name="Smart Bot")
    #print(new_bot.print_all(debug_mode=True))
    print(f"{new_bot.name} Memory: \n{new_bot.memories}\n\n{new_bot.name} Datasets: \n{new_bot.datasets}\n\n{new_bot.name} Session Messages: \n{new_bot.session_messages}\n") 
    # Initialize the Metaprompt agent
    while True:
        # Get user input
        user_input = input("User:\n")
        if user_input.lower() in ['exit', 'quit']:
            #Run Memory_Agent
            break
        # Process the input
        result = new_bot.generate_response(user_input, print_user=False)
    new_bot.end_session()

if __name__ == "__main__":

    # Start the main application
    main()