from dynamic_swarm.utils.prompts import *
from dynamic_swarm.init_db import init_db
from dynamic_swarm.agents.base import BaseAgent
from ollama import generate, chat
import sqlite3
from colorama import init, Fore, Style


# Initialize an agent with a pre-defined variables
def main():
    init(autoreset=True)
    # Step 1: Initialize the Database
    
    #init_bots()

    db_path = 'nuts.db'

    init_db(db_path)

    bot = BaseAgent(
        db_path = db_path,
        name = "basic bot",
        description="A helpful assistant bot.",
        prompt="You are a helpful AI Assistant.",
        test_mode=False
    )

    # Customize its behavior
    bot.add_dataset([
        {"title": "Sample Dataset", "description": "This dataset contains sample user-assistant interactions."},
        {"role": "user", "content": "What's the weather like today?"},
        {"role": "assistant", "content": "The weather is sunny with a high of 75°F and low wind. Perfect for a day outdoors!"},
        {"role": "user", "content": "Can you recommend any good books to read?"},
        {"role": "assistant", "content": "I'd suggest 'To Kill a Mockingbird' by Harper Lee or '1984' by George Orwell, both thought-provoking classics."}
    ])

    # Add things you would like it to never forget.
    bot.add_memory([
        {"title": "Greeting Memory", "description": "Memory of initial user greeting."},
        {"role": "user", "content": "Hello, My name is Mr. Awesome"},
        {"role": "assistant", "content": "Hello Mr. Awesome!"}
    ])

    # Start session
    bot.start_session()

    # Save the bot to a JSON file
    #bot.save_bot("bot_checkpoint_0.json")

    # Simulating a Session Conversation
    response = bot.generate_response("I have a friend named Jeff.")
    response = bot.generate_response("Jeff is cool.")

    #Save bot context window checkpoint
    #bot.save_bot("bot_checkpoint_1.json")
    bot.end_session()

    # Create new bots from basic bot
    clueless_bot = BaseAgent.create_from_bot(
        source_bot_name="basic bot",
        new_bot_name="Clueless Bot",
        new_description="A bot that doesn't know about the conversation context",
        db_path=db_path,
        checkpoint_number=0
    )
    
    # Create smart bot from final checkpoint (after session ended)
    smart_bot = BaseAgent.create_from_bot(
        source_bot_name="basic bot",
        new_bot_name="Smart Bot",
        new_description="A bot that remembers the conversation context",
        db_path=db_path,
        checkpoint_number=1
    )
    #clueless_bot.start_session()
    #smart_bot.start_session()
    # Set colors for terminal output
    clueless_bot.color = Fore.LIGHTRED_EX
    smart_bot.color = Fore.LIGHTMAGENTA_EX

    # Generate responses
    clueless_response = clueless_bot.generate_response("Tell me what you know about Jeff.")
    smart_response = smart_bot.generate_response("Tell me what you know about Jeff.")

    # End their sessions
    clueless_bot.end_session()
    smart_bot.end_session()

    new_bot = BaseAgent.create_from_bot(
        source_bot_name="basic bot",
        new_bot_name="New Bot",
        new_description="A bot that remembers the conversation context",
        db_path=db_path
    )
    new_bot.start_session()

    # Initialize the Metaprompt agent
    while True:
        # Get user input
        user_input = input("User:\n")
        if user_input.lower() in ['exit', 'quit']:
            #Run Memory_Agent
            break
        # Process the input
        result = new_bot.generate_response(user_input, print_user=False)
    new_bot.end_session()

if __name__ == "__main__":

    #Totally unecessary and just saying hi.
    options = { "temperature": 0.7 }
   # response = chat(model='llama3.2', messages=[{'role':'user','content':'Say Hello!'}])
    #print(f"{response['message']['content']}\n")

    # Start the main application
    main()