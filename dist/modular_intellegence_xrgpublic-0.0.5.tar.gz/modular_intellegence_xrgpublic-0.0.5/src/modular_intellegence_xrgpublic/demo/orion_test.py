from agents.base import BaseAgent
from colorama import init, Fore, Style
from stack import AgentStack
from database.config import Config

# Initialize colorama for colored output    
init(autoreset=True)

# Load agent directly
agent = BaseAgent(test_mode=True)
agent.load_from_db(name="Missy", checkpoint_id=2)
print(agent.print_all(debug_mode=False))

# Load stack and agent
stack = AgentStack(Config.DATABASE)
stack.load(db_path=Config.DATABASE, stack_id=1)
print(f"stack: {stack.name} {stack.description} {stack.id} ")


