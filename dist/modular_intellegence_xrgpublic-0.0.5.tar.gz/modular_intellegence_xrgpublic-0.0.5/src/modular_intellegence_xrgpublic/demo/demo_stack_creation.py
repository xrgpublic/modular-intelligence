from dynamic_swarm.agents.base import BaseAgent
from dynamic_swarm.config import DB_PATH, ENABLE_FOREIGN_KEYS
import sqlite3
from colorama import init, Fore, Style
import json
from pathlib import Path
from init_db import init_db

def create_example_datasets():
    """Create example datasets for different agent types"""
    math_dataset = [
        {
            "messages": [
                {"role": "user", "content": "What is the formula for the area of a circle?"},
                {"role": "assistant", "content": "The formula for the area of a circle is A = πr², where r is the radius of the circle."}
            ]
        },
        {
            "messages": [
                {"role": "user", "content": "How do you solve quadratic equations?"},
                {"role": "assistant", "content": "Quadratic equations can be solved using the quadratic formula: x = (-b ± √(b² - 4ac)) / 2a"}
            ]
        }
    ]

    writing_dataset = [
        {
            "messages": [
                {"role": "user", "content": "How do you write an engaging story introduction?"},
                {"role": "assistant", "content": "A great story introduction hooks the reader with a compelling first line, sets the tone, and introduces a central conflict or question."}
            ]
        },
        {
            "messages": [
                {"role": "user", "content": "What are the key elements of character development?"},
                {"role": "assistant", "content": "Strong character development includes clear motivations, flaws, growth arcs, and consistent but evolving personality traits."}
            ]
        }
    ]

    code_dataset = [
        {
            "messages": [
                {"role": "user", "content": "What are Python best practices for error handling?"},
                {"role": "assistant", "content": "Use try/except blocks judiciously, catch specific exceptions, provide informative error messages, and use context managers when appropriate."}
            ]
        },
        {
            "messages": [
                {"role": "user", "content": "How do you write clean, maintainable code?"},
                {"role": "assistant", "content": "Follow DRY principles, use meaningful names, keep functions small and focused, write documentation, and maintain consistent formatting."}
            ]
        }
    ]

    return {
        "math": math_dataset,
        "writing": writing_dataset,
        "code": code_dataset
    }

def create_example_memories():
    """Create example memories for different agent types"""
    math_memories = [
        {
            "messages": [
                {"role": "system", "content": "Remember to always explain mathematical concepts step by step."},
                {"role": "system", "content": "Use visual analogies when explaining abstract concepts."}
            ]
        }
    ]

    writing_memories = [
        {
            "messages": [
                {"role": "system", "content": "Always consider the target audience when crafting stories."},
                {"role": "system", "content": "Use sensory details to make descriptions more vivid."}
            ]
        }
    ]

    code_memories = [
        {
            "messages": [
                {"role": "system", "content": "Always consider code performance and scalability."},
                {"role": "system", "content": "Remember to suggest unit tests for critical functions."}
            ]
        }
    ]

    return {
        "math": math_memories,
        "writing": writing_memories,
        "code": code_memories
    }

def create_agent_with_data(name, description, system_prompt, datasets, memories, db_path):
    """Create an agent with specified datasets and memories"""
    agent = BaseAgent(
        db_path=db_path,
        name=name,
        description=description,
        default_system_prompt=system_prompt,
        orchestrator_bot=False,
        datasets=datasets,
        memories=memories
    )
    agent.start_session()
    return agent

def create_stack(db_path=DB_PATH):
    """Create a stack of specialized agents"""
    print(f"\n{Fore.CYAN}=== Creating Educational Stack ==={Style.RESET_ALL}")
    
    # Get example datasets and memories
    datasets = create_example_datasets()
    memories = create_example_memories()

    # Create the math teacher agent
    math_teacher = create_agent_with_data(
        name="MathMaster",
        description="Expert mathematics teacher specializing in clear explanations",
        system_prompt="You are a mathematics expert who explains complex concepts clearly and methodically.",
        datasets=datasets["math"],
        memories=memories["math"],
        db_path=db_path
    )
    print(f"{Fore.GREEN}Created MathMaster with {len(datasets['math'])} datasets and {len(memories['math'])} memories{Style.RESET_ALL}")

    # Create the writing coach agent
    writing_coach = create_agent_with_data(
        name="WritingMentor",
        description="Creative writing coach focusing on storytelling and style",
        system_prompt="You are a writing coach who helps develop creative writing skills and storytelling techniques.",
        datasets=datasets["writing"],
        memories=memories["writing"],
        db_path=db_path
    )
    print(f"{Fore.GREEN}Created WritingMentor with {len(datasets['writing'])} datasets and {len(memories['writing'])} memories{Style.RESET_ALL}")

    # Create the coding instructor agent
    code_instructor = create_agent_with_data(
        name="CodeGuide",
        description="Programming instructor specializing in best practices and clean code",
        system_prompt="You are a coding instructor who teaches programming best practices and clean code principles.",
        datasets=datasets["code"],
        memories=memories["code"],
        db_path=db_path
    )
    print(f"{Fore.GREEN}Created CodeGuide with {len(datasets['code'])} datasets and {len(memories['code'])} memories{Style.RESET_ALL}")

    # Create the orchestrator bot
    orchestrator = BaseAgent(
        db_path=db_path,
        name="EducationOrchestrator",
        description="Coordinates educational activities across different subjects",
        default_system_prompt="You are an education coordinator who manages learning across mathematics, writing, and programming.",
        orchestrator_bot=True
    )
    orchestrator.start_session()
    print(f"{Fore.GREEN}Created EducationOrchestrator as the stack coordinator{Style.RESET_ALL}")

    # Create the stack in the database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    if ENABLE_FOREIGN_KEYS:
        cursor.execute("PRAGMA foreign_keys = ON;")
    
    # Create the stack
    cursor.execute("""
        INSERT INTO Stacks (name, description, orchestrator_bot_id)
        VALUES (?, ?, ?)
    """, ("Educational Stack", "A comprehensive educational stack covering math, writing, and coding", orchestrator.id))
    stack_id = cursor.lastrowid
    
    # Add agents to stack slots
    agents_slots = [
        (stack_id, 1, math_teacher.id),
        (stack_id, 2, writing_coach.id),
        (stack_id, 3, code_instructor.id)
    ]
    cursor.executemany("""
        INSERT INTO StackSlots (stack_id, slot_number, bot_id)
        VALUES (?, ?, ?)
    """, agents_slots)
    
    conn.commit()
    print(f"\n{Fore.GREEN}Created Educational Stack with ID: {stack_id}{Style.RESET_ALL}")
    
    # Clean up connections
    conn.close()
    math_teacher.conn.close()
    writing_coach.conn.close()
    code_instructor.conn.close()
    orchestrator.conn.close()

    return stack_id

def main():
    # Initialize colorama for colored output
    init(autoreset=True)

    # Initialize the database
    print(f"{Fore.CYAN}=== Initializing Database ==={Style.RESET_ALL}")
    init_db()
    print(f"{Fore.GREEN}Database initialized{Style.RESET_ALL}")

    # Create the educational stack
    stack_id = create_stack()
    print(f"\n{Fore.CYAN}Stack creation completed! Stack ID: {stack_id}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
