from dynamic_swarm.agents.base import BaseAgent
from dynamic_swarm.config import DB_PATH
import sqlite3
from colorama import init, Fore, Style
import init_db 

def main():
    # Initialize colorama for colored output
    init(autoreset=True)

    # Initialize the database first
    print(f"{Fore.CYAN}=== Initializing Database ==={Style.RESET_ALL}\n")
    init_db.init_database()
    print(f"{Fore.GREEN}Database initialized{Style.RESET_ALL}\n")

    print(f"{Fore.CYAN}=== Creating and Saving Agents Demo ==={Style.RESET_ALL}\n")

    # Create first agent - A helpful teaching assistant
    teacher_bot = BaseAgent(
        name="TeacherBot",
        description="A helpful teaching assistant that explains concepts clearly.",
        default_system_prompt="You are a patient and knowledgeable teaching assistant. You explain complex concepts in simple terms.",
        orchestrator_bot=False,
        db_path=DB_PATH
    )
    teacher_bot.start_session()
    print(f"{Fore.GREEN}Created TeacherBot{Style.RESET_ALL}")

    # Create second agent - A creative storyteller
    story_bot = BaseAgent(
        name="StoryBot",
        description="A creative storyteller that crafts engaging narratives.",
        default_system_prompt="You are a creative storyteller. You weave imaginative tales that captivate your audience.",
        orchestrator_bot=False,
        db_path=DB_PATH
    )
    story_bot.start_session()
    print(f"{Fore.GREEN}Created StoryBot{Style.RESET_ALL}")

    # Create third agent - A code reviewer
    code_bot = BaseAgent(
        name="CodeBot",
        description="A thorough code reviewer that provides helpful feedback.",
        default_system_prompt="You are a code reviewer. You analyze code and provide constructive feedback to improve code quality.",
        orchestrator_bot=False,
        db_path=DB_PATH
    )
    code_bot.start_session()
    print(f"{Fore.GREEN}Created CodeBot{Style.RESET_ALL}")

    # Save all agents to database with checkpoints
    print(f"\n{Fore.CYAN}=== Saving Agents to Database ==={Style.RESET_ALL}")
    teacher_bot.save_to_db(status="initial_save")
    story_bot.save_to_db(status="initial_save")
    code_bot.save_to_db(status="initial_save")
    print(f"{Fore.GREEN}All agents saved to database{Style.RESET_ALL}")

    # Create a new agent and load from an existing one
    print(f"\n{Fore.CYAN}=== Creating New Agent from Existing One ==={Style.RESET_ALL}")
    math_teacher = BaseAgent(
        name="MathTeacher",
        description="A specialized math teacher that explains mathematical concepts.",
        default_system_prompt="You are a specialized math teacher. You explain mathematical concepts clearly and provide helpful examples.",
        orchestrator_bot=False,
        db_path=DB_PATH
    )
    math_teacher.start_session()
    print(f"{Fore.GREEN}Created new MathTeacher{Style.RESET_ALL}")

    # Load an existing agent
    print(f"\n{Fore.CYAN}=== Loading Existing Agent ==={Style.RESET_ALL}")
    loaded_bot = BaseAgent(db_path=DB_PATH)
    loaded_bot.load_from_db(name="StoryBot")
    print(f"{Fore.GREEN}Successfully loaded StoryBot from database{Style.RESET_ALL}")
    print(f"Name: {loaded_bot.name}")
    print(f"Description: {loaded_bot.description}")
    print(f"System Prompt: {loaded_bot.system_prompt}")

    # Clean up
    teacher_bot.conn.close()
    story_bot.conn.close()
    code_bot.conn.close()
    math_teacher.conn.close()
    loaded_bot.conn.close()

if __name__ == "__main__":
    main()
