import sqlite3
from modular_intellegence_xrgpublic.database.config import Config
from modular_intellegence_xrgpublic.database.init_db import init_database
import os

def rebuild_database(dir_path=Config.DATABASE, schema_path=Config.SCHEMA_PATH):
    """ Deletes the database and reinitializes it """
    init_database(rebuild=True, dir_path=dir_path, schema_path=schema_path)


if __name__ == "__main__":
    rebuild_database()
